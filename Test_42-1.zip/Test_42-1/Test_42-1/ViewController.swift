//
//  ViewController.swift
//  Test_42-1
//
//  Created by AKKI on 08/02/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tblTest: UITableView!
    
    struct Constant {
        static let cellIdentifier = "Test_43"
    }
    
    let cities: [String] = ["City - A", "City - B", "City - C", "City - D", "City - E", "City - F", "City - G", "City - H", "City - I", "City - J"]
    
    let country: [String: String] = ["City - A": "Country - A", "City - B": "Country - B", "City - C": "Country - C", "City - D": "Country - D", "City - E": "Country - E", "City - F": "Country - F", "City - G": "Country - G", "City - H": "Country - H", "City - I": "Country - I", "City - J": "Country - J"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tblTest.delegate = self
        tblTest.dataSource = self
        
        tblTest.register(UITableViewCell.self, forCellReuseIdentifier: Constant.cellIdentifier)
    }


}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Constant.cellIdentifier, for: indexPath)
        
        let city = cities[indexPath.row]
        var cellConfig = cell.defaultContentConfiguration()
        cellConfig.text = city
        cellConfig.secondaryText = country[city]
        cell.contentConfiguration = cellConfig
        
        return cell
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Cell click --> \(cities[indexPath.row]) = \(country[cities[indexPath.row]] ?? "")")
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
